const LOCAL_API = 'http://localhost:4000/api';

let autoStartInFlight = false;
function ensureHeartbeatAlarm() { chrome.alarms.create('orbit-heartbeat', { periodInMinutes: 0.5 }); }
chrome.runtime.onInstalled.addListener(ensureHeartbeatAlarm);
chrome.runtime.onStartup.addListener(ensureHeartbeatAlarm);
ensureHeartbeatAlarm();
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== 'orbit-heartbeat') return;
  heartbeat().then(autoStartApprovedQueue).catch(() => undefined);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  route(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message || 'Orbit extension error.' }));
  return true;
});

async function route(message) {
  if (message.type === 'PAIR') return pair(message.code, message.apiBase);
  if (message.type === 'STATUS') return status();
  if (message.type === 'PROCESS_NEXT') return processNext();
  if (message.type === 'SET_AUTO_RUN') return setAutoRun(message.enabled);
  if (message.type === 'RESUME_APPROVED') return resumeApproved();
  if (message.type === 'MARK_RESULT') return markResult(message.state, message.reason);
  throw new Error('Unsupported extension command.');
}

async function pair(code, apiBaseValue) {
  const apiBase = normalizeApiBase(apiBaseValue);
  const result = await api('/operator-extension/pair', { method: 'POST', body: { code, browserName: navigator.userAgent.slice(0, 120) }, anonymous: true, apiBase });
  await chrome.storage.local.set({ orbitToken: result.token, orbitApiBase: apiBase, workspaceId: result.workspaceId, pairedAt: new Date().toISOString(), autoRunEnabled: true });
  return { ok: true, workspaceId: result.workspaceId };
}

async function status() {
  const stored = await chrome.storage.local.get(['orbitToken', 'workspaceId', 'activeActionId', 'activeTabId', 'autoRunEnabled']);
  if (!stored.orbitToken) return { ok: true, paired: false };
  try {
    const health = await api('/operator-extension/heartbeat', { method: 'POST' });
    let action = null;
    if (stored.activeActionId) action = await api(`/operator-extension/actions/${stored.activeActionId}`);
    return { ok: true, paired: true, connected: health.connected, workspaceId: stored.workspaceId, action, autoRunEnabled: stored.autoRunEnabled !== false };
  } catch (error) {
    if (error.status === 401) {
      await chrome.storage.local.remove(['orbitToken', 'orbitApiBase', 'workspaceId', 'pairedAt', 'activeActionId', 'activeTabId', 'activeProfileUrl']);
      return { ok: false, paired: false, connected: false, error: 'This pairing was revoked or expired. Generate a new code in Orbit.' };
    }
    return { ok: false, paired: true, connected: false, error: error.message };
  }
}

async function heartbeat() {
  const { orbitToken } = await chrome.storage.local.get('orbitToken');
  if (!orbitToken) return;
  await api('/operator-extension/heartbeat', { method: 'POST' });
}

async function setAutoRun(enabled) {
  await chrome.storage.local.set({ autoRunEnabled: Boolean(enabled) });
  if (enabled) await autoStartApprovedQueue();
  return { ok: true, autoRunEnabled: Boolean(enabled), message: enabled ? 'Approved queues will start automatically.' : 'Automatic queue start is off.' };
}

async function autoStartApprovedQueue() {
  if (autoStartInFlight) return;
  const stored = await chrome.storage.local.get(['orbitToken', 'activeActionId', 'autoRunEnabled']);
  if (!stored.orbitToken || stored.activeActionId || stored.autoRunEnabled === false) return;
  autoStartInFlight = true;
  try {
    const result = await processNext();
    if (result?.waitingApproval) await chrome.action.setBadgeText({ text: '1' });
    else if (result?.empty) await chrome.action.setBadgeText({ text: '' });
    else if (result?.paused) await chrome.action.setBadgeText({ text: '!' });
  } finally {
    autoStartInFlight = false;
  }
}

async function processNext() {
  let action;
  try {
    action = await api('/operator-extension/next', { method: 'POST' });
    if (!action?.id) return { ok: true, empty: true, message: 'No approved profile is ready.' };
    const profileUrl = action.contact?.profileUrl || action.targetUrl;
    const platform = platformForAction(action, profileUrl);
    if (!profileUrl) throw new Error('The approved action does not contain a profile URL.');
    if (!platform) throw new Error('The approved action does not identify a supported platform.');
    const activityUrl = recentActivityUrl(profileUrl, platform);
    const tab = await chrome.tabs.create({ url: activityUrl, active: true });
    await chrome.storage.local.set({ activeActionId: action.id, activeTabId: tab.id, activeProfileUrl: profileUrl });
    await waitForTab(tab.id);
    await ensureContentScript(tab.id);
    const observed = await chrome.tabs.sendMessage(tab.id, { type: 'READ_RECENT_POST', platform });
    if (!observed?.postText || observed.postText.trim().length < 20) throw new Error(observed?.reason || 'No readable recent post was found. Open the post manually and retry.');
    const generated = await api(`/operator-extension/actions/${action.id}/analyze-visible-post`, { method: 'POST', body: { publicPostText: observed.postText, recentPostUrl: observed.postUrl || tab.url } });
    return { ok: true, action, waitingApproval: generated.shouldEngage, skipped: !generated.shouldEngage, intentSummary: generated.intentSummary, draft: generated.draft, message: generated.shouldEngage ? 'Gemini draft created. Approve it in Orbit, then click Resume approved draft.' : 'Gemini recommended skipping this post.' };
  } catch (error) {
    if (action?.id) await api(`/operator-extension/actions/${action.id}/result`, { method: 'POST', body: { state: 'PAUSED', reason: error.message || 'The browser worker paused unexpectedly.' } }).catch(() => undefined);
    return { ok: false, action, paused: Boolean(action), error: error.message || 'The browser worker paused unexpectedly.' };
  }
}

async function resumeApproved() {
  const stored = await chrome.storage.local.get(['activeActionId', 'activeTabId', 'activeProfileUrl']);
  if (!stored.activeActionId) throw new Error('No active Orbit action.');
  const action = await api(`/operator-extension/actions/${stored.activeActionId}`);
  if (action.state !== 'READY_TO_TYPE') return { ok: false, waitingApproval: true, action, error: `Draft is ${action.state.replaceAll('_', ' ').toLowerCase()}. Approve it in Orbit first.` };
  let tabId = stored.activeTabId;
  let tab = tabId ? await chrome.tabs.get(tabId).catch(() => null) : null;
  if (!tab) {
    tab = await chrome.tabs.create({ url: action.recentPostUrl || stored.activeProfileUrl || action.targetUrl, active: true });
    tabId = tab.id;
    await waitForTab(tabId);
  } else {
    await chrome.tabs.update(tabId, { active: true, url: action.recentPostUrl || tab.url });
    await waitForTab(tabId);
  }
  await ensureContentScript(tabId);
  const prepared = await chrome.tabs.sendMessage(tabId, { type: 'PREPARE_ACTION', actionType: action.actionType, draft: action.content || '' });
  if (!prepared?.ok) throw new Error(prepared?.reason || 'Could not prepare the approved action on this page.');
  await api(`/operator-extension/actions/${action.id}/typed`, { method: 'POST' });
  await chrome.action.setBadgeText({ text: '' });
  return { ok: true, action: { ...action, state: 'AWAITING_FINAL_CONFIRMATION' }, message: prepared.message || 'Approved draft is ready. Review the page and perform the final platform action yourself.' };
}

async function markResult(state, reason) {
  const { activeActionId } = await chrome.storage.local.get('activeActionId');
  if (!activeActionId) throw new Error('No active Orbit action.');
  const result = await api(`/operator-extension/actions/${activeActionId}/result`, { method: 'POST', body: { state, reason } });
  await chrome.action.setBadgeText({ text: '' });
  await chrome.storage.local.remove(['activeActionId', 'activeTabId', 'activeProfileUrl']);
  return { ok: true, action: result };
}

async function api(path, options = {}) {
  const stored = options.anonymous ? {} : await chrome.storage.local.get(['orbitToken', 'orbitApiBase']);
  const response = await fetch(`${options.apiBase || stored.orbitApiBase || LOCAL_API}${path}`, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(stored.orbitToken ? { Authorization: `Bearer ${stored.orbitToken}` } : {}) },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const responseText = await response.text();
  const body = responseText ? JSON.parse(responseText) : null;
  if (!response.ok) {
    const error = new Error(Array.isArray(body?.message) ? body.message.join(' ') : body?.message || `Orbit API error ${response.status}.`);
    error.status = response.status;
    throw error;
  }
  return body;
}

function normalizeApiBase(value) {
  const apiUrl = new URL(String(value || 'http://localhost:4000/api'));
  if (!['https:', 'http:'].includes(apiUrl.protocol) || (apiUrl.protocol === 'http:' && !['localhost', '127.0.0.1'].includes(apiUrl.hostname))) throw new Error('Orbit API must use HTTPS outside localhost.');
  return `${apiUrl.origin}${apiUrl.pathname.replace(/\/$/, '') || '/api'}`;
}

function recentActivityUrl(profileUrl, platform) {
  if (String(platform).toUpperCase() === 'LINKEDIN' && /linkedin\.com\/in\//i.test(profileUrl)) return `${profileUrl.replace(/\/?$/, '')}/recent-activity/all/`;
  return profileUrl;
}

function platformForAction(action, profileUrl) {
  const declared = action?.connectedAccount?.platform || action?.contact?.platform;
  if (declared) return String(declared).toUpperCase();
  const hostname = (() => { try { return new URL(profileUrl).hostname.toLowerCase(); } catch { return ''; } })();
  if (hostname.includes('linkedin.com')) return 'LINKEDIN';
  if (hostname.includes('instagram.com')) return 'INSTAGRAM';
  if (hostname.includes('reddit.com')) return 'REDDIT';
  if (hostname.includes('quora.com')) return 'QUORA';
  return '';
}

function waitForTab(tabId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); reject(new Error('Profile page took too long to load.')); }, 30_000);
    const listener = (updatedId, info) => {
      if (updatedId === tabId && info.status === 'complete') { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(); }
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => { if (tab.status === 'complete') { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(); } });
  });
}

async function ensureContentScript(tabId) {
  try { await chrome.tabs.sendMessage(tabId, { type: 'PING' }); }
  catch { await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }); }
}
