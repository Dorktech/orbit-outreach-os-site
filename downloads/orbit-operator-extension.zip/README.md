# Orbit Operator Companion

This Manifest V3 Chrome extension pairs a Chrome profile with a local Orbit OS workspace. It can open the next approved profile, read visible public post text, request a Gemini draft through the Orbit backend, and type that draft after it is approved in Orbit.

It does not read cookies or passwords, automate login, or click a final Send, Post, Comment, or Like control. Those final social actions remain manual.

## Install locally

1. Extract `orbit-operator-extension.zip`.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the extracted folder containing `manifest.json`.
5. In Orbit OS → Operator Agent, click **Generate pairing code**.
6. Open the extension, enter the Orbit dashboard URL and code, then click **Pair browser**. The production GitHub Pages dashboard automatically connects to `https://orbit-api.credestate.cloud/api`.

Orbit API must be running at `http://localhost:4000`.

For production, enter the HTTPS dashboard origin. The extension requests access only to that selected Orbit origin. Release ZIPs are produced by GitHub Actions with a SHA-256 checksum.

Chrome does not permit normal Windows or macOS users to receive automatic updates from a self-hosted GitHub CRX. GitHub Releases therefore provide signed/checksummed delivery artifacts; automatic extension installation and updates for general users must use the Chrome Web Store. Enterprise-managed Chrome can use a separately signed CRX update channel.

## Chrome Web Store release

The store submission assets and disclosure copy are in `store-assets/` and `STORE_LISTING.md`. Generate icons and the required promotional image with `node scripts/generate-extension-store-assets.mjs`, then prepare a least-privilege upload directory with `node scripts/prepare-extension-release.mjs <version> <output> chrome-store`. The public privacy policy is hosted at `https://dorktech.github.io/orbit-outreach-os-site/privacy.html`.
