const elements = {
  pairingView: document.querySelector('#pairing-view'), operatorView: document.querySelector('#operator-view'),
  code: document.querySelector('#pairing-code'), orbitUrl: document.querySelector('#orbit-url'), consent: document.querySelector('#data-consent'), pair: document.querySelector('#pair-button'),
  process: document.querySelector('#process-button'), resume: document.querySelector('#resume-button'), autoRun: document.querySelector('#auto-run'),
  complete: document.querySelector('#complete-button'), skip: document.querySelector('#skip-button'),
  dot: document.querySelector('#connection-dot'), connection: document.querySelector('#connection-label'),
  workspace: document.querySelector('#workspace-label'), actionCard: document.querySelector('#action-card'),
  actionTitle: document.querySelector('#action-title'), actionState: document.querySelector('#action-state'),
  actionSummary: document.querySelector('#action-summary'), message: document.querySelector('#message')
};
let currentAction = null;

elements.code.addEventListener('input', () => { elements.code.value = elements.code.value.toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 8); setBusy(false); });
elements.consent.addEventListener('change', () => setBusy(false));
elements.pair.addEventListener('click', pairBrowser);
elements.process.addEventListener('click', () => run('PROCESS_NEXT', {}, 'Profile analyzed. Review the generated draft in Orbit Approvals.'));
elements.autoRun.addEventListener('change', () => run('SET_AUTO_RUN', { enabled: elements.autoRun.checked }, elements.autoRun.checked ? 'Approved queues will start automatically.' : 'Automatic queue start is off.'));
elements.resume.addEventListener('click', () => run('RESUME_APPROVED', {}, 'Approved draft prepared in the page. Review it before the final click.'));
elements.complete.addEventListener('click', () => run('MARK_RESULT', { state: 'COMPLETED' }, 'Action marked completed.'));
elements.skip.addEventListener('click', () => run('MARK_RESULT', { state: 'SKIPPED', reason: 'Skipped by the user from the extension.' }, 'Profile skipped.'));

async function send(type, payload = {}) { return chrome.runtime.sendMessage({ type, ...payload }); }

async function pairBrowser() {
  try {
    const dashboardUrl = new URL(elements.orbitUrl.value.trim());
    if (!['https:', 'http:'].includes(dashboardUrl.protocol) || (dashboardUrl.protocol === 'http:' && !['localhost', '127.0.0.1'].includes(dashboardUrl.hostname))) throw new Error('Use an HTTPS Orbit URL. HTTP is allowed only for localhost development.');
    if (!elements.consent.checked) throw new Error('Review and accept the visible-content disclosure before pairing.');
    const apiBase = apiBaseFromDashboard(dashboardUrl);
    await run('PAIR', { code: elements.code.value, apiBase }, 'Browser paired successfully.');
  } catch (error) { show(error.message || 'Enter a valid Orbit dashboard URL.', true); }
}

function apiBaseFromDashboard(dashboardUrl) {
  if (['localhost', '127.0.0.1'].includes(dashboardUrl.hostname)) return 'http://localhost:4000/api';
  if (dashboardUrl.hostname === 'dorktech.github.io') return 'https://orbit-api.credestate.cloud/api';
  return `${dashboardUrl.origin}/api`;
}

async function run(type, payload, successText) {
  setBusy(true); show('');
  try {
    const result = await send(type, payload);
    if (!result?.ok) throw new Error(result?.error || result?.message || 'Orbit could not complete this step.');
    show(result.message || successText);
    await refresh();
  } catch (error) { show(error.message || 'Orbit extension error.', true); }
  finally { setBusy(false); }
}

async function refresh() {
  const status = await send('STATUS');
  const paired = Boolean(status?.paired);
  elements.pairingView.hidden = paired;
  elements.operatorView.hidden = !paired;
  elements.dot.classList.toggle('online', Boolean(status?.connected));
  if (!paired) { setBusy(false); return; }
  elements.connection.textContent = status.connected ? 'Connected to Orbit' : 'Orbit API offline';
  elements.workspace.textContent = status.workspaceId ? `Workspace ${status.workspaceId.slice(0, 8)}` : 'Orbit workspace';
  elements.autoRun.checked = status.autoRunEnabled !== false;
  renderAction(status.action);
  if (status.error) show(status.error, true);
}

function renderAction(action) {
  currentAction = action || null;
  elements.actionCard.hidden = !action;
  if (!action) { setBusy(false); return; }
  elements.actionTitle.textContent = action.actionType.replaceAll('_', ' ').toLowerCase();
  elements.actionState.textContent = action.state.replaceAll('_', ' ');
  elements.actionSummary.textContent = action.intentSummary || action.connectedAccount?.displayName || 'Active operator action';
  elements.resume.disabled = action.state !== 'READY_TO_TYPE';
  elements.complete.disabled = action.state !== 'AWAITING_FINAL_CONFIRMATION';
}

function setBusy(busy) {
  elements.pair.disabled = busy || elements.code.value.length !== 8 || !elements.consent.checked;
  elements.process.disabled = busy;
  elements.resume.disabled = busy || currentAction?.state !== 'READY_TO_TYPE';
  elements.complete.disabled = busy || currentAction?.state !== 'AWAITING_FINAL_CONFIRMATION';
  elements.skip.disabled = busy || !currentAction;
}
function show(text, error = false) { elements.message.textContent = text; elements.message.classList.toggle('error', error); }

refresh().catch((error) => show(error.message, true));
