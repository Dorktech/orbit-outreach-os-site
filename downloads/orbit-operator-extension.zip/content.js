(() => {
  if (window.__orbitOperatorLoaded) return;
  window.__orbitOperatorLoaded = true;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === 'PING') { sendResponse({ ok: true }); return; }
    if (message.type === 'READ_RECENT_POST') { sendResponse(readRecentPost(message.platform)); return; }
    if (message.type === 'PREPARE_ACTION') { prepareAction(message).then(sendResponse).catch((error) => sendResponse({ ok: false, reason: error.message })); return true; }
  });

  function readRecentPost(platform) {
    const selectors = String(platform).toUpperCase() === 'LINKEDIN'
      ? ['div.feed-shared-update-v2', 'div[data-urn*="activity"]', 'article']
      : String(platform).toUpperCase() === 'REDDIT'
        ? ['shreddit-post', 'article']
        : ['article', '[role="article"]'];
    const container = firstVisible(selectors);
    if (!container) return { ok: false, reason: 'No visible recent post container was found.' };
    const textNode = firstVisible(['.update-components-text', '.feed-shared-update-v2__description', '[data-ad-preview="message"]', '[slot="text-body"]', '[data-testid="post-content"]'], container) || container;
    const postText = (textNode.innerText || textNode.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 12_000);
    const link = Array.from(container.querySelectorAll('a[href]')).find((anchor) => /\/posts\/|\/feed\/update\/|\/comments\//i.test(anchor.href));
    showStatus('Orbit read the visible recent post. Gemini is preparing an individualized draft.', 'working');
    return { ok: postText.length >= 20, postText, postUrl: link?.href || location.href, reason: postText.length < 20 ? 'The recent post did not expose enough readable text.' : undefined };
  }

  async function prepareAction({ actionType, draft }) {
    if (document.querySelector('input[type="password"]:focus')) throw new Error('Orbit will not interact with password fields.');
    const normalized = String(actionType).toUpperCase();
    if (normalized === 'LIKE') {
      const like = findButton(['Like', 'React', 'Upvote']);
      if (!like) throw new Error('Like/react control was not found.');
      await pointAt(like);
      highlight(like);
      showStatus('Like control highlighted. Click it yourself to perform the final social action.', 'confirm');
      return { ok: true, message: 'Like control highlighted; final click requires you.' };
    }
    if (!draft?.trim()) throw new Error('Approved Gemini draft is empty.');
    const alsoLike = normalized === 'COMMENT_AND_LIKE';
    if (normalized === 'DIRECT_MESSAGE') {
      const messageButton = findButton(['Message', 'Send message']);
      if (!messageButton) throw new Error('Message button was not found.');
      await pointAt(messageButton); messageButton.click(); await delay(800);
    } else {
      const commentButton = findButton(['Comment', 'Reply']);
      if (commentButton) { await pointAt(commentButton); commentButton.click(); await delay(500); }
    }
    const editor = await waitForEditor();
    await pointAt(editor);
    typeInto(editor, draft.trim());
    highlight(editor);
    if (alsoLike) {
      const like = findButton(['Like', 'React', 'Upvote']);
      if (like) highlight(like);
      showStatus('Approved Gemini comment typed and Like highlighted. Review the comment, submit it, and click Like yourself.', 'confirm');
      return { ok: true, message: 'Comment typed and Like highlighted; both final clicks require you.' };
    }
    showStatus('Approved Gemini draft typed. Review it and click the final Send/Post button yourself.', 'confirm');
    return { ok: true, message: 'Draft typed successfully; final submission requires you.' };
  }

  function firstVisible(selectors, root = document) {
    for (const selector of selectors) {
      const found = Array.from(root.querySelectorAll(selector)).find(isVisible);
      if (found) return found;
    }
    return null;
  }
  function isVisible(element) { const rect = element.getBoundingClientRect(); const style = getComputedStyle(element); return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none'; }
  function findButton(labels) { return Array.from(document.querySelectorAll('button,[role="button"]')).find((button) => isVisible(button) && labels.some((label) => `${button.getAttribute('aria-label') || ''} ${button.innerText || ''}`.toLowerCase().includes(label.toLowerCase()))); }
  async function waitForEditor() {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const editor = firstVisible(['[contenteditable="true"][role="textbox"]', '[contenteditable="true"]', 'textarea:not([type="password"])']);
      if (editor) return editor;
      await delay(250);
    }
    throw new Error('Comment/message editor was not found. Open it manually, then resume.');
  }
  function typeInto(editor, text) {
    if (editor.matches('input[type="password"]')) throw new Error('Orbit will not type into password fields.');
    editor.focus();
    if (editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement) {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(editor), 'value')?.set;
      setter?.call(editor, text); editor.dispatchEvent(new Event('input', { bubbles: true })); editor.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      editor.textContent = ''; document.execCommand('insertText', false, text); editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    }
  }
  async function pointAt(element) {
    const cursor = cursorElement(); const rect = element.getBoundingClientRect(); cursor.style.transform = `translate(${Math.max(8, rect.left + Math.min(rect.width / 2, 80))}px,${Math.max(8, rect.top + Math.min(rect.height / 2, 24))}px)`; await delay(350);
  }
  function cursorElement() {
    let cursor = document.getElementById('orbit-visible-cursor');
    if (!cursor) { cursor = document.createElement('div'); cursor.id = 'orbit-visible-cursor'; cursor.textContent = '➤'; Object.assign(cursor.style, { position:'fixed', left:'0', top:'0', zIndex:'2147483647', color:'#6f61d9', fontSize:'26px', textShadow:'0 2px 8px white', pointerEvents:'none', transition:'transform .32s ease' }); document.documentElement.appendChild(cursor); }
    return cursor;
  }
  function highlight(element) { element.style.outline = '3px solid #6f61d9'; element.style.outlineOffset = '3px'; element.scrollIntoView({ behavior:'smooth', block:'center' }); }
  function showStatus(text, mode) {
    let status = document.getElementById('orbit-operator-status');
    if (!status) { status = document.createElement('div'); status.id = 'orbit-operator-status'; Object.assign(status.style, { position:'fixed', right:'18px', bottom:'18px', zIndex:'2147483647', maxWidth:'360px', padding:'13px 15px', borderRadius:'12px', color:'#fff', font:'600 13px system-ui', boxShadow:'0 15px 45px rgba(0,0,0,.25)' }); document.documentElement.appendChild(status); }
    status.style.background = mode === 'confirm' ? '#6f4d18' : '#174f3c'; status.textContent = text;
  }
  function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
})();
